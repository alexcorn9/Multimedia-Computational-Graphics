import java.util.Scanner;

public class AreaPerimeterCalculator {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("=== Area & Perimeter Calculator ===");
        System.out.println("1. Square");
        System.out.println("2. Rectangle");
        System.out.println("3. Triangle (equilateral)");
        System.out.println("4. Circle");
        System.out.println("5. Regular Pentagon");
        System.out.print("Choose a shape: ");

        int option = sc.nextInt();

        double area = 0;
        double perimeter = 0;

        switch (option) {
            case 1 -> {
                System.out.print("Enter side length: ");
                double side = sc.nextDouble();
                area = side * side;
                perimeter = 4 * side;
            }
            case 2 -> {
                System.out.print("Enter length: ");
                double length = sc.nextDouble();
                System.out.print("Enter width: ");
                double width = sc.nextDouble();
                area = length * width;
                perimeter = 2 * (length + width);
            }
            case 3 -> { // Equilateral triangle
                System.out.print("Enter side length: ");
                double tSide = sc.nextDouble();
                area = (Math.sqrt(3) / 4) * tSide * tSide;
                perimeter = 3 * tSide;
            }
            case 4 -> {
                System.out.print("Enter radius: ");
                double radius = sc.nextDouble();
                area = Math.PI * radius * radius;
                perimeter = 2 * Math.PI * radius;
            }
            case 5 -> { // Regular pentagon
                System.out.print("Enter side length: ");
                double pSide = sc.nextDouble();
                perimeter = 5 * pSide;
                area = (5 * pSide * pSide) / (4 * Math.tan(Math.PI / 5));
            }
            default -> {
                System.out.println("Invalid option.");
                sc.close();
                return;
            }
        }

        System.out.println("\nArea: " + area);
        System.out.println("Perimeter: " + perimeter);

        sc.close();
    }
}
