package Classwork.Classwork_01;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Diagonal {

    public static void main(String[] args) {

        int width = 800;   // 4
        int height = 600;  // 3

        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        // It's a for loop that uses the slope equation as its base, red on top of it and blue below
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                if ((double) y > (3.0 / 4.0) * x) {
                    image.setRGB(x, y, Color.BLUE.getRGB());
                } else {
                    image.setRGB(x, y, Color.RED.getRGB());
                }
            }
        }
        try {
            ImageIO.write(image, "jpg", new File("Diagonal.jpg"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}