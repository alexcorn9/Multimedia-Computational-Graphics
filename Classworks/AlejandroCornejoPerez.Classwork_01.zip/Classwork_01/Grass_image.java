package Classwork.Classwork_01;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Grass_image {

    public static void main(String[] args) {

        int width = 800;
        int height = 600;

        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        // Grass parameters
        int center = (height / 2) + 150;
        int amplitude = 30;
        double frequency = 0.05;

        // Sun parameters
        int cx = 180;
        int cy = 150;
        int radius = 100;

        // Draw grass using sin(x)
        for (int x = 0; x < width; x++) {
            int ySin = (int)(center + amplitude * Math.sin(frequency * x));

            for (int y = 0; y < height; y++) {
                if (y > ySin) {
                    image.setRGB(x, y, Color.GREEN.getRGB()); // grass
                } else {
                    image.setRGB(x, y, Color.WHITE.getRGB()); // sky
                }
            }
        }

        // Draw filled sun
        for (int x = cx - radius; x <= cx + radius; x++) {
            for (int y = cy - radius; y <= cy + radius; y++) {

                if (x >= 0 && x < width && y >= 0 && y < height) {
                    if ((x - cx)*(x - cx) + (y - cy)*(y - cy) <= radius*radius) {
                        image.setRGB(x, y, Color.YELLOW.getRGB());
                    }
                }
            }
        }

        // Draw sun rays
        for (int angle = 0; angle < 360; angle += 45) {

            double theta = Math.toRadians(angle);

            for (int r = radius; r < radius + 40; r++) {
                int x = (int)(cx + r * Math.cos(theta));
                int y = (int)(cy + r * Math.sin(theta));

                if (x >= 0 && x < width && y >= 0 && y < height) {
                    image.setRGB(x, y, Color.RED.getRGB());
                }
            }
        }

        try {
            ImageIO.write(image, "jpg", new File("Grass_image.jpg"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
