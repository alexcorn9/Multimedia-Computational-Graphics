package Classwork.Classwork_01;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Clock {
    public static void main(String[] args) {
    int width = 800;   // 4
    int height = 600;  // 3

    BufferedImage image = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);

// Variables that mark the center and size of the clock
int cx = width / 2;
int cy = height / 2;
int margin = 20;
// R2 is the radius where the dots of the clock are marked
int R1 = (height / 2 - margin);
int R2 = R1 - 50;
// These are the radius that the hour and minute sticks are gonna have
int minute_rad = R2 - 20;
int hour_rad = R2 - 60;

// Here is where we set the time that we want the clock to show
int minute = 5;
int hour = 10;

// Makes sure that the hour that was input is put in terms of the clock
hour = hour % 12;

// Circle for clock
for (double deg = 0; deg < 360; deg += 0.5) {
    // Converts the degrees into radians
    double theta = Math.toRadians(deg);

    //Polar coordinates
    int x = (int) (cx + R1 * Math.cos(theta));
    int y = (int) (cy + R1 * Math.sin(theta));

    // As long as the circle is inside the screen, it will paint it
    if (x >= 0 && x < width && y >= 0 && y < height) {
        image.setRGB(x, y, Color.WHITE.getRGB());
    }
}
//Dots to mark time
for (double deg = 0; deg < 360; deg += 1) {
    double theta = Math.toRadians(deg); 

    int x = ((int) (cx + R2 * Math.cos(theta)));
    int y = (int) (cy + R2 * Math.sin(theta));

    if (((int)deg) % 30 == 0)
        {
        image.setRGB(x, y, Color.WHITE.getRGB());
    }
}

// Converts the mintues and hours that were input earlier and converts them to angles
double minuteAngle = minute * 6.0;              // 360/60 = 6
double thetaMin = Math.toRadians(minuteAngle - 90);

double hourAngle = hour * 30.0;                 // 360/12 = 30
double thetaHour = Math.toRadians(hourAngle - 90);


// Uses circles and paints every pixel that's on the same direction until it reaches the radius of the minute stick
for (int r = 0; r < minute_rad; r++) {
        int x = (int) (cx + r * Math.cos(thetaMin));
        int y = (int) (cy + r * Math.sin(thetaMin));
        image.setRGB(x, y, Color.WHITE.getRGB());
    }
    
for (int r = 0; r < hour_rad; r++) {
    int x = (int) (cx + r * Math.cos(thetaHour));
    int y = (int) (cy + r * Math.sin(thetaHour));
    image.setRGB(x, y, Color.WHITE.getRGB());
    }
    

        try {
            ImageIO.write(image, "jpg", new File("Clock1.jpg"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
