import java.util.Scanner;

public class AreaPerimeterCalculator {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("=== Area & Perimeter Calculator ===");
        System.out.println("1. Square");
        System.out.println("2. Rectangle");
        System.out.println("3. Triangle");
        System.out.println("4. Circle");
        System.out.println("5. Regular Pentagon");
        System.out.print("Choose a shape: ");

        int option = sc.nextInt();

        double area = 0;
        double perimeter = 0;

        switch (option) {

            case 1: // Square
                System.out.print("Enter side length: ");
                double side = sc.nextDouble();
                area = side * side;
                perimeter = 4 * side;
                break;

            case 2: // Rectangle
                System.out.print("Enter length: ");
                double length = sc.nextDouble();
                System.out.print("Enter width: ");
                double width = sc.nextDouble();
                area = length * width;
                perimeter = 2 * (length + width);
                break;

            case 3: // Any triangle (Heron's formula)
                System.out.print("Enter side A: ");
                double a = sc.nextDouble();
                System.out.print("Enter side B: ");
                double b = sc.nextDouble();
                System.out.print("Enter side C: ");
                double c = sc.nextDouble();

                // Validate triangle
                if (a + b <= c || a + c <= b || b + c <= a) {
                    System.out.println("Invalid triangle.");
                    sc.close();
                    return;
                }

                perimeter = a + b + c;
                double s = perimeter / 2;
                area = Math.sqrt(s * (s - a) * (s - b) * (s - c));
                break;

            case 4: // Circle
                System.out.print("Enter radius: ");
                double radius = sc.nextDouble();
                area = Math.PI * radius * radius;
                perimeter = 2 * Math.PI * radius;
                break;

            case 5: // Pentagon
                System.out.print("Enter side length: ");
                double pSide = sc.nextDouble();
                perimeter = 5 * pSide;
                area = (5 * pSide * pSide) / (4 * Math.tan(Math.PI / 5));
                break;

            default:
                System.out.println("Invalid option.");
                sc.close();
                return;
        }

        System.out.println("\nArea: " + area);
        System.out.println("Perimeter: " + perimeter);

        sc.close();
    }
}
