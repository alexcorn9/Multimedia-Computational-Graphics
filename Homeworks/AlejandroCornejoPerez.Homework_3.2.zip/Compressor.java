import java.io.*;         
import java.util.zip.*; 

public class Compressor {

    public static void main(String[] args) {
        // CheckS that the user provided at least 3 words
        // 1) "mode", 2) "input file", and 3) "output file"
        if (args.length < 3) {
            System.out.println("""
                Usage:
                  java Compressor compress photo.png compressed.zip
                  java Compressor decompress compressed.zip output.png
                """);
            return;
        }
        try {
            // Select the operation based on the first word
            if (args[0].equals("compress")) {
                compress(args[1], args[2]);   // Uses compress method
            } else if (args[0].equals("decompress")) {
                decompress(args[1], args[2]); // Uses decompress method
            }
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Method that compresses an image file to a ZIP
    static void compress(String input, String output) throws IOException {
        // References to the original and zip files
        File original = new File(input);
        File zipFile = new File(output);

        // Creates the ZIP file
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile));
             FileInputStream fis = new FileInputStream(original)) {
            ZipEntry entry = new ZipEntry(original.getName());
            zos.putNextEntry(entry);

            // Copy all bytes from the image file into the ZIP archive
            fis.transferTo(zos);
            zos.closeEntry();
        }
        System.out.println("Image successfully compressed using ZIP.");
    }    

    // Decompress method that extracts the image file from a ZIP archive
    static void decompress(String input, String output) throws IOException {
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(input));
             FileOutputStream fos = new FileOutputStream(output)) {
            zis.getNextEntry();
            
            // Writes the extracted bytes from the zip into the output of an image file
            zis.transferTo(fos);
        }
        System.out.println("Image decompressed.");
    }
}