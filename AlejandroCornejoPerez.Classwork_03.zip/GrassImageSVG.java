package Classwork.Classwork_03;
import java.io.FileWriter;
import java.io.IOException;

public class GrassImageSVG {

    public static void main(String[] args) {

        int width = 800;
        int height = 600;

        // Grass parameters
        int center = (height / 2) + 150;
        int amplitude = 30;
        double frequency = 0.05;

        // Sun parameters
        int cx = 180;
        int cy = 150;
        int radius = 100;

        // Build grass shape using sin(x)
        StringBuilder grassPath = new StringBuilder();

        int y0 = (int)(center + amplitude * Math.sin(frequency * 0));
        grassPath.append("M 0 ").append(y0).append(" ");

        for (int x = 1; x < width; x++) {
            int ySin = (int)(center + amplitude * Math.sin(frequency * x));
            grassPath.append("L ").append(x).append(" ").append(ySin).append(" ");
        }

        grassPath.append("L ").append(width).append(" ").append(height).append(" ");
        grassPath.append("L 0 ").append(height).append(" Z");

        // Build sun rays
        StringBuilder rays = new StringBuilder();

        for (int angle = 0; angle < 360; angle += 45) {

            double theta = Math.toRadians(angle);

            int x1 = (int)(cx + radius * Math.cos(theta));
            int y1 = (int)(cy + radius * Math.sin(theta));

            int x2 = (int)(cx + (radius + 40) * Math.cos(theta));
            int y2 = (int)(cy + (radius + 40) * Math.sin(theta));

            rays.append("<line x1=\"").append(x1)
                .append("\" y1=\"").append(y1)
                .append("\" x2=\"").append(x2)
                .append("\" y2=\"").append(y2)
                .append("\" stroke=\"red\" stroke-width=\"4\" />\n");
        }

        // SVG document Script
        String svg =
            "<svg width=\"" + width + "\" height=\"" + height + "\" " +
            "viewBox=\"0 0 " + width + " " + height + "\" " +
            "xmlns=\"http://www.w3.org/2000/svg\">\n" +

            // Sky background
            "<rect width=\"100%\" height=\"100%\" fill=\"white\" />\n" +

            // Grass area
            "<path d=\"" + grassPath + "\" fill=\"green\" />\n" +

            // Sun rays
            rays +

            // Sun circle
            "<circle cx=\"" + cx + "\" cy=\"" + cy +
            "\" r=\"" + radius + "\" fill=\"yellow\" />\n" +

            "</svg>";

        try (FileWriter file = new FileWriter("Grass_image.svg")) {
            file.write(svg);
            System.out.println("SVG created");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}