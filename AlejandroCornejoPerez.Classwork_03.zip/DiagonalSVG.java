package Classwork.Classwork_03;
import java.io.FileWriter;
import java.io.IOException;

public class DiagonalSVG {

    public static void main(String[] args) {

        // Dimensions
        int width = 800;
        int height = 600;

        // Intersection point of the line y = (3/4)x with the canvas
        // In this case it reaches the bottom-right corner
        int xInterseccion = width;
        int yInterseccion = height;

        // SVG content as a string
        String svg =
            "<svg width=\"" + width + "\" height=\"" + height + "\" " +
            "viewBox=\"0 0 " + width + " " + height + "\" " +
            "xmlns=\"http://www.w3.org/2000/svg\">\n" +

            // BLUE region, it starts at 0,0, ends at 800,600 and makes a polygon by also joining 800,0
            "<polygon points=\"0,0 " +
            xInterseccion + ",0 " +
            xInterseccion + "," + yInterseccion +
            "\" fill=\"blue\" />\n" +

            // RED region it starts at 0,0, ends at 800,600 and makes a polygon by also joining 0,600
            "<polygon points=\"0,0 0," +
            yInterseccion + " " +
            xInterseccion + "," + yInterseccion +
            "\" fill=\"red\" />\n" +

            "</svg>";

        try (FileWriter writer = new FileWriter("Diagonal.svg")) {
            // Write the SVG content into a file
            writer.write(svg);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
