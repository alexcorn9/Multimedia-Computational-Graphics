package Homework.Homework_2;

import java.util.Scanner;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Aspect_Ratio {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Which resolution do you want?");
        System.out.println("Enter width and height:");

        int width = sc.nextInt();
        int height = sc.nextInt();

        // This loop finds out the GCD between the two numbers
        int currentWidth = width;
        int currentHeight = height;
        while (currentHeight != 0) {
            int remainder = currentWidth % currentHeight;
            currentWidth = currentHeight;
            currentHeight = remainder;
        }
        int gcd = currentWidth;

        int aspectWidth = width / gcd;
        int aspectHeight = height / gcd;

        System.out.println("Your aspect ratio is: " + aspectWidth + ":" + aspectHeight);

        // The image is black by default
        BufferedImage image =
                new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        try {
            ImageIO.write(image, "jpg", new File("Aspect_Ratio.jpg"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}