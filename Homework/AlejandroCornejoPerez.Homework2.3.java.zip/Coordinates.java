package Homework.Homework_2;
import java.util.Scanner;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Coordinates {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Polar to Cartesian and Cartesian to Polar Coordinates");
        System.out.println("Enter 1 to convert Polar coordinates to Cartesian");
        System.out.println("Enter 2 to convert Cartesian coordinates to Polar");

        int option = sc.nextInt();

        switch (option) {

            case 1: // Polar Coordinates to Cartesian
                System.out.print("Enter your radius: ");
                double radius = sc.nextDouble();
                System.out.print("Enter your angle in degrees: ");
                double deg = sc.nextDouble();
                double radians = Math.toRadians(deg);
                double Cartesian_x = radius * Math.cos(radians);
                double Cartesian_y = radius * Math.sin(radians);
                System.out.println("Your Cartesian coordinates are: " + Cartesian_x + " and " + Cartesian_y);
                break;

            case 2: // Cartesian Coordinates to Polar
                System.out.print("Enter your x coordinate ");
                double x = sc.nextDouble();
                System.out.print("Enter your y coordinate ");
                double y = sc.nextDouble();
                double Polar_radius = Math.sqrt(x*x + y*y);
                double Phi = Math.atan2(y, x);
                double Polar_angle = Math.toDegrees(Phi);
                System.out.println("Your Polar coordiantes are: " + Polar_radius + " and " + Polar_angle);


        }
    }
}