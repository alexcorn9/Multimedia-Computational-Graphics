package Classwork.Classwork_02;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Barycentric_triangle {
    public static void main(String[] args) {
        // Here's where we defin the resolution and aspect ratio of the image
        int width = 500;
        int height = 500;
        BufferedImage image = new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);

        // Here we define the points of the triangle
        int Xa = 0;
        int Ya = 500;

        int Xb = 500;
        int Yb = 500;

        int Xc = 250;
        int Yc = 0;

        // Here's where we define the colors of the points in the triangle
        // Red point A
        int rA = 255;
        int rB = 0;
        int rC = 0;

        // Green point B
        int gA = 0;
        int gB = 255;
        int gC = 0;

        // Blue point C
        int bA = 0;
        int bB = 0;
        int bC = 255;

        // This for cycle goes through every point in the image and if the pixel is inside the triangle, it's painted with a different color than the last one
        for (int x=0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                float den = ((Yb - Yc) * (Xa - Xc) + (Xc - Xb) * (Ya - Yc));
                float delta1 = ((Yb - Yc) * (x - Xc) + (Xc - Xb) * (y - Yc)) / (den);
                float delta2 = ((Yc - Ya) * (x - Xc) + (Xa - Xc) * (y - Yc)) / (den);
                float delta3 = 1 - delta1 - delta2;
                if (delta1 >= 0 && + delta2 >= 0 && delta3 >= 0){
                    int r = (int)(delta1 * rA + delta2 * rB + delta3 * rC);
                    int g = (int)(delta1 * gA + delta2 * gB + delta3 * gC);
                    int b = (int)(delta1 * bA + delta2 * bB + delta3 * bC);
                    Color color = new Color(r, g, b);
                    image.setRGB(x, y, color.getRGB());
                }
            }
        }
        try {
            ImageIO.write(image, "jpg", new File("Barycentric_3.jpg"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}